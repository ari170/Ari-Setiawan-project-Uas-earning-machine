# PyRacing
Youtube project 3. PyRacing

A.I. learns how to drive with reinforcement learning

Pygame + OpenAI GYM

![30000-9 mp4_000012500](https://user-images.githubusercontent.com/16572520/65689228-db30a980-e06c-11e9-811e-59d6a4c550dc.gif)

![30000-dark1 mp4_000013600](https://user-images.githubusercontent.com/16572520/65689229-dc61d680-e06c-11e9-894f-91e3512437c8.gif)
